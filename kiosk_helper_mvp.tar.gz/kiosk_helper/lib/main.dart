import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // 세로 모드 고정 (어르신 사용 편의)
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);

  runApp(const KioskHelperApp());
}

class KioskHelperApp extends StatelessWidget {
  const KioskHelperApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '키오스크 도우미',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1B5E20), // 진한 초록 — 신뢰감, 가독성
          brightness: Brightness.light,
        ),
        // ── 어르신 맞춤 텍스트 크기 ──
        textTheme: const TextTheme(
          headlineLarge: TextStyle(
            fontSize: 32, fontWeight: FontWeight.bold, height: 1.3,
          ),
          headlineMedium: TextStyle(
            fontSize: 26, fontWeight: FontWeight.w600, height: 1.3,
          ),
          bodyLarge: TextStyle(
            fontSize: 20, fontWeight: FontWeight.w400, height: 1.6,
          ),
          bodyMedium: TextStyle(
            fontSize: 18, fontWeight: FontWeight.w400, height: 1.5,
          ),
          labelLarge: TextStyle(
            fontSize: 22, fontWeight: FontWeight.w600,
          ),
        ),
        // ── 큰 버튼, 큰 터치 영역 ──
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            minimumSize: const Size(double.infinity, 64),
            textStyle: const TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
          hintStyle: const TextStyle(fontSize: 18),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
