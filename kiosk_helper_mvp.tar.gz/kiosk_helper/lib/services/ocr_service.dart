import 'dart:io';
import 'dart:ui';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import '../models/scan_result.dart';

/// Google ML Kit OCR 래퍼 서비스
///
/// - 이미지에서 텍스트 + 좌표(bounding box) 추출
/// - 사용자 검색어와 매칭되는 블록 필터링
class OcrService {
  // 한국어 인식기 사용
  final _recognizer = TextRecognizer(script: TextRecognitionScript.korean);

  /// 이미지 파일에서 OCR 수행 → ScanResult 반환
  Future<ScanResult> scanImage({
    required String imagePath,
    required String userQuery,
  }) async {
    final inputImage = InputImage.fromFilePath(imagePath);
    final recognized = await _recognizer.processImage(inputImage);

    // 이미지 크기 얻기 (오버레이 좌표 변환에 필요)
    final file = File(imagePath);
    final bytes = await file.readAsBytes();
    final codec = await instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    final imageWidth = frame.image.width;
    final imageHeight = frame.image.height;
    frame.image.dispose();

    // 모든 텍스트 블록 추출
    final allBlocks = <OcrBlock>[];
    for (final block in recognized.blocks) {
      for (final line in block.lines) {
        // 라인 단위로 처리 (블록보다 세밀한 매칭 가능)
        final bb = line.boundingBox;
        allBlocks.add(OcrBlock(
          text: line.text,
          boundingBox: Rect.fromLTRB(
            bb.left.toDouble(),
            bb.top.toDouble(),
            bb.right.toDouble(),
            bb.bottom.toDouble(),
          ),
        ));
      }
    }

    // 사용자 쿼리와 매칭
    final matched = _findMatches(allBlocks, userQuery);

    return ScanResult(
      allBlocks: allBlocks,
      matchedBlocks: matched,
      userQuery: userQuery,
      imageWidth: imageWidth,
      imageHeight: imageHeight,
    );
  }

  /// 매칭 로직: 다단계 검색
  ///
  /// 1) 정확히 일치하는 텍스트
  /// 2) 포함(contains) 관계
  /// 3) 초성/부분 매칭 (향후 확장)
  List<OcrBlock> _findMatches(List<OcrBlock> blocks, String query) {
    if (query.isEmpty) return [];

    final normalizedQuery = _normalize(query);
    final results = <OcrBlock>[];

    // 1단계: 정확 매칭 또는 포함 매칭
    for (final block in blocks) {
      final normalizedText = _normalize(block.text);
      if (normalizedText.contains(normalizedQuery)) {
        results.add(block);
      }
    }

    // 2단계: 키워드 분리 매칭 (예: "아이스 아메리카노" → "아이스", "아메리카노")
    if (results.isEmpty) {
      final keywords = normalizedQuery.split(' ').where((k) => k.length >= 2);
      for (final block in blocks) {
        final normalizedText = _normalize(block.text);
        if (keywords.any((kw) => normalizedText.contains(kw))) {
          results.add(block);
        }
      }
    }

    // 3단계: 유사도 기반 (단순 문자 겹침 비율)
    if (results.isEmpty && normalizedQuery.length >= 2) {
      final scored = <MapEntry<OcrBlock, double>>[];
      for (final block in blocks) {
        final score = _similarity(_normalize(block.text), normalizedQuery);
        if (score > 0.5) {
          scored.add(MapEntry(block, score));
        }
      }
      scored.sort((a, b) => b.value.compareTo(a.value));
      results.addAll(scored.take(3).map((e) => e.key));
    }

    return results;
  }

  /// 텍스트 정규화: 공백 제거, 소문자 변환
  String _normalize(String text) {
    return text.replaceAll(RegExp(r'\s+'), '').toLowerCase();
  }

  /// 간단한 문자 유사도 (Jaccard-like)
  double _similarity(String a, String b) {
    if (a.isEmpty || b.isEmpty) return 0.0;
    final setA = a.split('').toSet();
    final setB = b.split('').toSet();
    final intersection = setA.intersection(setB).length;
    final union = setA.union(setB).length;
    return intersection / union;
  }

  /// 리소스 해제
  void dispose() {
    _recognizer.close();
  }
}
