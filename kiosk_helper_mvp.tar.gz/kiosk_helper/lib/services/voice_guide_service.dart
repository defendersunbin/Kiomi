import 'package:flutter_tts/flutter_tts.dart';

/// 음성 안내 서비스
///
/// 어르신에게 "여기를 눌러주세요" 같은 안내를 음성으로 전달
class VoiceGuideService {
  final FlutterTts _tts = FlutterTts();
  bool _isInitialized = false;

  /// 초기화: 한국어, 느린 속도, 큰 볼륨
  Future<void> init() async {
    if (_isInitialized) return;

    await _tts.setLanguage('ko-KR');
    await _tts.setSpeechRate(0.4);  // 느리게 (0.0~1.0, 기본 0.5)
    await _tts.setVolume(1.0);      // 최대 볼륨
    await _tts.setPitch(1.0);       // 기본 피치

    _isInitialized = true;
  }

  /// 텍스트를 음성으로 읽기
  Future<void> speak(String text) async {
    await init();
    await _tts.speak(text);
  }

  /// 매칭 결과에 따른 안내 음성
  Future<void> guideMatch(String menuName) async {
    await speak('화면에서 $menuName 을 찾았습니다. 빨간 원이 표시된 곳을 눌러주세요.');
  }

  /// 매칭 실패 시 안내
  Future<void> guideNoMatch(String menuName) async {
    await speak('화면에서 $menuName 을 찾지 못했습니다. 다시 한번 카메라로 비춰주세요.');
  }

  /// 음성 중지
  Future<void> stop() async {
    await _tts.stop();
  }

  void dispose() {
    _tts.stop();
  }
}
