import 'dart:io';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:path_provider/path_provider.dart';
import '../services/ocr_service.dart';
import '../services/voice_guide_service.dart';
import '../models/scan_result.dart';
import '../widgets/guide_overlay.dart';

/// 스캔 화면
///
/// 1) 카메라 프리뷰 표시
/// 2) 사용자가 "스캔" 버튼 탭
/// 3) 사진 촬영 → OCR → 매칭 → 오버레이 + 음성 안내
/// 4) "다음 단계" 탭 시 다시 스캔
class ScanScreen extends StatefulWidget {
  final String userQuery;

  const ScanScreen({super.key, required this.userQuery});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  CameraController? _cameraController;
  final _ocrService = OcrService();
  final _voiceGuide = VoiceGuideService();

  bool _isInitialized = false;
  bool _isScanning = false;

  // 스캔 결과
  ScanResult? _scanResult;
  String? _capturedImagePath;

  @override
  void initState() {
    super.initState();
    _initCamera();
    _voiceGuide.init().then((_) {
      _voiceGuide.speak(
        '${widget.userQuery}을 찾아드릴게요. 카메라로 키오스크 화면을 비춘 후, 아래 스캔 버튼을 눌러주세요.',
      );
    });
  }

  Future<void> _initCamera() async {
    final cameras = await availableCameras();
    if (cameras.isEmpty) {
      _showError('카메라를 찾을 수 없습니다.');
      return;
    }

    // 후면 카메라 사용
    final backCamera = cameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.back,
      orElse: () => cameras.first,
    );

    _cameraController = CameraController(
      backCamera,
      ResolutionPreset.high, // 고해상도로 OCR 정확도 향상
      enableAudio: false,
    );

    try {
      await _cameraController!.initialize();
      if (mounted) {
        setState(() => _isInitialized = true);
      }
    } catch (e) {
      _showError('카메라 초기화 실패: $e');
    }
  }

  /// 스캔 실행: 촬영 → OCR → 매칭 → 결과 표시
  Future<void> _performScan() async {
    if (_cameraController == null || _isScanning) return;

    setState(() {
      _isScanning = true;
      _scanResult = null;
    });

    try {
      // 1. 사진 촬영
      final xFile = await _cameraController!.takePicture();

      // 임시 파일로 저장
      final dir = await getTemporaryDirectory();
      final targetPath = '${dir.path}/kiosk_scan_${DateTime.now().millisecondsSinceEpoch}.jpg';
      await File(xFile.path).copy(targetPath);

      // 2. OCR 수행
      final result = await _ocrService.scanImage(
        imagePath: targetPath,
        userQuery: widget.userQuery,
      );

      // 3. 결과 업데이트
      setState(() {
        _scanResult = result;
        _capturedImagePath = targetPath;
        _isScanning = false;
      });

      // 4. 음성 안내
      if (result.hasMatch) {
        await _voiceGuide.guideMatch(widget.userQuery);
      } else {
        await _voiceGuide.guideNoMatch(widget.userQuery);
      }
    } catch (e) {
      setState(() => _isScanning = false);
      _showError('스캔 중 오류가 발생했습니다: $e');
    }
  }

  /// 다시 스캔 (다음 단계)
  void _resetScan() {
    setState(() {
      _scanResult = null;
      _capturedImagePath = null;
    });
    _voiceGuide.speak('다시 키오스크 화면을 비춰주세요.');
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message, style: const TextStyle(fontSize: 18))),
    );
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    _ocrService.dispose();
    _voiceGuide.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            // ── 상단 바: 검색어 표시 + 뒤로가기 ──
            Container(
              color: Colors.black87,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white, size: 28),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      '찾는 중: ${widget.userQuery}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ── 카메라 프리뷰 / 캡처 이미지 + 오버레이 ──
            Expanded(
              child: _buildCameraArea(),
            ),

            // ── 하단 컨트롤 ──
            Container(
              color: Colors.black87,
              padding: const EdgeInsets.all(20),
              child: _buildBottomControls(theme),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCameraArea() {
    // 스캔 결과가 있으면: 캡처된 이미지 + 오버레이
    if (_scanResult != null && _capturedImagePath != null) {
      return LayoutBuilder(
        builder: (context, constraints) {
          final previewSize = Size(
            constraints.maxWidth,
            constraints.maxHeight,
          );
          return Stack(
            fit: StackFit.expand,
            children: [
              // 캡처된 이미지
              Image.file(
                File(_capturedImagePath!),
                fit: BoxFit.contain,
              ),
              // 가이드 오버레이
              if (_scanResult!.hasMatch)
                GuideOverlay(
                  scanResult: _scanResult!,
                  previewSize: previewSize,
                ),
              // 매칭 실패 시 안내
              if (!_scanResult!.hasMatch)
                Center(
                  child: Container(
                    padding: const EdgeInsets.all(24),
                    margin: const EdgeInsets.all(32),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.search_off, color: Colors.white, size: 48),
                        const SizedBox(height: 16),
                        Text(
                          '"${widget.userQuery}"을(를)\n화면에서 찾지 못했어요',
                          style: const TextStyle(
                            color: Colors.white, fontSize: 22, height: 1.4,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          '키오스크 화면이 잘 보이도록\n다시 비춰주세요',
                          style: TextStyle(
                            color: Colors.white70, fontSize: 18, height: 1.4,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          );
        },
      );
    }

    // 카메라 프리뷰
    if (!_isInitialized || _cameraController == null) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: Colors.white),
            SizedBox(height: 16),
            Text(
              '카메라 준비 중...',
              style: TextStyle(color: Colors.white, fontSize: 20),
            ),
          ],
        ),
      );
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        CameraPreview(_cameraController!),
        // 스캔 중 로딩
        if (_isScanning)
          Container(
            color: Colors.black54,
            child: const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 4,
                  ),
                  SizedBox(height: 20),
                  Text(
                    '화면을 분석하고 있어요...',
                    style: TextStyle(color: Colors.white, fontSize: 22),
                  ),
                ],
              ),
            ),
          ),
        // 가이드 프레임 (촬영 전)
        if (!_isScanning)
          Center(
            child: Container(
              width: 300,
              height: 400,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white54, width: 2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text(
                    '키오스크 화면을\n이 안에 맞춰주세요',
                    style: TextStyle(
                      color: Colors.white70, fontSize: 18, height: 1.4,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildBottomControls(ThemeData theme) {
    // 결과가 있으면: "다시 스캔" + "다음 단계" 버튼
    if (_scanResult != null) {
      return Row(
        children: [
          Expanded(
            child: ElevatedButton.icon(
              onPressed: _resetScan,
              icon: const Icon(Icons.refresh, size: 24),
              label: const Text('다시 스캔'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey.shade800,
                foregroundColor: Colors.white,
                minimumSize: const Size(0, 64),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () {
                // 같은 검색어로 다음 화면 스캔
                _resetScan();
                _voiceGuide.speak(
                  '키오스크를 누르신 후, 바뀐 화면을 다시 비춰주세요.',
                );
              },
              icon: const Icon(Icons.arrow_forward, size: 24),
              label: const Text('다음 단계'),
              style: ElevatedButton.styleFrom(
                backgroundColor: theme.colorScheme.primary,
                foregroundColor: Colors.white,
                minimumSize: const Size(0, 64),
              ),
            ),
          ),
        ],
      );
    }

    // 스캔 버튼
    return ElevatedButton.icon(
      onPressed: _isScanning ? null : _performScan,
      icon: const Icon(Icons.document_scanner, size: 28),
      label: Text(_isScanning ? '분석 중...' : '📸 스캔하기'),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.red.shade600,
        foregroundColor: Colors.white,
        disabledBackgroundColor: Colors.grey,
        minimumSize: const Size(double.infinity, 72),
        textStyle: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
      ),
    );
  }
}
