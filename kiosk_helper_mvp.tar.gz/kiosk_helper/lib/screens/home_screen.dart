import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'scan_screen.dart';

/// 홈 화면
///
/// 1) 원하는 메뉴를 말하거나 입력
/// 2) 스캔 화면으로 이동
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _textController = TextEditingController();
  final _speech = stt.SpeechToText();
  bool _isListening = false;

  // ── 자주 쓰는 메뉴 빠른 선택 ──
  static const _quickMenus = [
    '아메리카노',
    '카페라떼',
    '아이스티',
    '결제하기',
    '포장',
    '매장',
  ];

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  /// 음성 입력 시작/중지
  Future<void> _toggleListening() async {
    if (_isListening) {
      await _speech.stop();
      setState(() => _isListening = false);
      return;
    }

    final available = await _speech.initialize(
      onError: (error) {
        setState(() => _isListening = false);
      },
    );

    if (available) {
      setState(() => _isListening = true);
      await _speech.listen(
        onResult: (result) {
          setState(() {
            _textController.text = result.recognizedWords;
          });
          if (result.finalResult) {
            setState(() => _isListening = false);
          }
        },
        localeId: 'ko_KR',
        listenFor: const Duration(seconds: 10),
      );
    }
  }

  /// 스캔 화면으로 이동
  void _goToScan(String query) {
    if (query.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('찾고 싶은 메뉴를 입력해주세요', style: TextStyle(fontSize: 18)),
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ScanScreen(userQuery: query.trim()),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 20),

              // ── 제목 ──
              Text(
                '키오스크 도우미',
                style: theme.textTheme.headlineLarge?.copyWith(
                  color: theme.colorScheme.primary,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                '원하시는 메뉴를 알려주세요.\n키오스크에서 어디를 눌러야 하는지\n안내해 드립니다.',
                style: theme.textTheme.bodyLarge?.copyWith(
                  color: Colors.grey.shade700,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 32),

              // ── 음성 입력 버튼 ──
              ElevatedButton.icon(
                onPressed: _toggleListening,
                icon: Icon(
                  _isListening ? Icons.mic : Icons.mic_none,
                  size: 32,
                ),
                label: Text(
                  _isListening ? '듣고 있어요...' : '🎙️ 말로 메뉴 입력하기',
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isListening
                      ? Colors.red.shade100
                      : theme.colorScheme.primaryContainer,
                  foregroundColor: _isListening
                      ? Colors.red.shade800
                      : theme.colorScheme.onPrimaryContainer,
                  minimumSize: const Size(double.infinity, 72),
                ),
              ),
              const SizedBox(height: 16),

              // ── 텍스트 입력 ──
              TextField(
                controller: _textController,
                style: const TextStyle(fontSize: 22),
                decoration: const InputDecoration(
                  hintText: '예: 아메리카노',
                  prefixIcon: Icon(Icons.search, size: 28),
                ),
                onSubmitted: _goToScan,
              ),
              const SizedBox(height: 16),

              // ── 스캔 시작 버튼 ──
              ElevatedButton.icon(
                onPressed: () => _goToScan(_textController.text),
                icon: const Icon(Icons.camera_alt, size: 28),
                label: const Text('📸 키오스크 스캔하기'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: theme.colorScheme.primary,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 72),
                ),
              ),

              const SizedBox(height: 32),
              const Divider(),
              const SizedBox(height: 16),

              // ── 자주 찾는 메뉴 (빠른 선택) ──
              Text(
                '자주 찾는 메뉴',
                style: theme.textTheme.headlineMedium,
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: _quickMenus.map((menu) {
                  return SizedBox(
                    height: 56,
                    child: OutlinedButton(
                      onPressed: () {
                        _textController.text = menu;
                        _goToScan(menu);
                      },
                      style: OutlinedButton.styleFrom(
                        textStyle: const TextStyle(fontSize: 20),
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(menu),
                    ),
                  );
                }).toList(),
              ),

              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
}
