import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/scan_result.dart';

/// 카메라 프리뷰 위에 가이드 오버레이를 그리는 위젯
///
/// - 매칭된 텍스트 위치에 빨간 원 + 테두리
/// - "여기를 누르세요" 라벨
/// - 펄스 애니메이션으로 시선 유도
class GuideOverlay extends StatefulWidget {
  final ScanResult scanResult;
  final Size previewSize; // 화면에 표시되는 프리뷰 크기

  const GuideOverlay({
    super.key,
    required this.scanResult,
    required this.previewSize,
  });

  @override
  State<GuideOverlay> createState() => _GuideOverlayState();
}

class _GuideOverlayState extends State<GuideOverlay>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    // 펄스 애니메이션: 빨간 원이 살짝 커졌다 작아졌다
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.15).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return CustomPaint(
          size: widget.previewSize,
          painter: _GuidePainter(
            scanResult: widget.scanResult,
            previewSize: widget.previewSize,
            pulseScale: _pulseAnimation.value,
          ),
        );
      },
    );
  }
}

class _GuidePainter extends CustomPainter {
  final ScanResult scanResult;
  final Size previewSize;
  final double pulseScale;

  _GuidePainter({
    required this.scanResult,
    required this.previewSize,
    required this.pulseScale,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (!scanResult.hasMatch) return;

    // 이미지 좌표 → 화면 좌표 변환 비율
    final scaleX = previewSize.width / scanResult.imageWidth;
    final scaleY = previewSize.height / scanResult.imageHeight;

    for (final block in scanResult.matchedBlocks) {
      // 원본 이미지 좌표를 화면 좌표로 변환
      final rect = Rect.fromLTRB(
        block.boundingBox.left * scaleX,
        block.boundingBox.top * scaleY,
        block.boundingBox.right * scaleX,
        block.boundingBox.bottom * scaleY,
      );

      _drawHighlight(canvas, rect);
      _drawLabel(canvas, rect);
    }
  }

  /// 매칭된 영역에 빨간 하이라이트 + 펄스 효과
  void _drawHighlight(Canvas canvas, Rect rect) {
    final center = rect.center;
    final radius = math.max(rect.width, rect.height) / 2 + 12;

    // 반투명 빨간 배경
    final fillPaint = Paint()
      ..color = Colors.red.withOpacity(0.15)
      ..style = PaintingStyle.fill;

    // 빨간 테두리 (펄스 애니메이션)
    final strokePaint = Paint()
      ..color = Colors.red.withOpacity(0.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.0;

    // 펄스 적용
    final animatedRadius = radius * pulseScale;

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: center,
          width: rect.width + 24 * pulseScale,
          height: rect.height + 20 * pulseScale,
        ),
        const Radius.circular(12),
      ),
      fillPaint,
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: center,
          width: rect.width + 24 * pulseScale,
          height: rect.height + 20 * pulseScale,
        ),
        const Radius.circular(12),
      ),
      strokePaint,
    );

    // 화살표: 위에서 아래로 가리키기
    final arrowPaint = Paint()
      ..color = Colors.red
      ..style = PaintingStyle.fill;

    final arrowTip = Offset(center.dx, rect.top - 10);
    final path = Path()
      ..moveTo(arrowTip.dx, arrowTip.dy)
      ..lineTo(arrowTip.dx - 12, arrowTip.dy - 24)
      ..lineTo(arrowTip.dx + 12, arrowTip.dy - 24)
      ..close();
    canvas.drawPath(path, arrowPaint);
  }

  /// "여기를 누르세요" 라벨
  void _drawLabel(Canvas canvas, Rect rect) {
    const labelText = '👆 여기를 누르세요';
    final textSpan = TextSpan(
      text: labelText,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 18,
        fontWeight: FontWeight.bold,
        shadows: [Shadow(color: Colors.black87, blurRadius: 4)],
      ),
    );
    final textPainter = TextPainter(
      text: textSpan,
      textDirection: TextDirection.ltr,
    )..layout();

    // 라벨 배경
    final labelRect = Rect.fromLTWH(
      rect.center.dx - textPainter.width / 2 - 12,
      rect.top - 70,
      textPainter.width + 24,
      textPainter.height + 12,
    );
    final bgPaint = Paint()
      ..color = Colors.red.shade700
      ..style = PaintingStyle.fill;
    canvas.drawRRect(
      RRect.fromRectAndRadius(labelRect, const Radius.circular(8)),
      bgPaint,
    );

    // 텍스트
    textPainter.paint(
      canvas,
      Offset(labelRect.left + 12, labelRect.top + 6),
    );
  }

  @override
  bool shouldRepaint(covariant _GuidePainter oldDelegate) {
    return oldDelegate.pulseScale != pulseScale ||
        oldDelegate.scanResult != scanResult;
  }
}
