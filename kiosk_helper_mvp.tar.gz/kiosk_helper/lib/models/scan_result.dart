import 'dart:ui';

/// OCR로 인식된 개별 텍스트 블록
class OcrBlock {
  final String text;
  final Rect boundingBox; // 화면 상의 좌표 (원본 이미지 기준)

  const OcrBlock({
    required this.text,
    required this.boundingBox,
  });

  /// 검색어가 이 블록의 텍스트에 포함되어 있는지 확인
  bool containsQuery(String query) {
    final normalizedText = text.replaceAll(' ', '').toLowerCase();
    final normalizedQuery = query.replaceAll(' ', '').toLowerCase();
    return normalizedText.contains(normalizedQuery);
  }

  @override
  String toString() => 'OcrBlock("$text", $boundingBox)';
}

/// 전체 스캔 결과
class ScanResult {
  final List<OcrBlock> allBlocks;     // OCR로 인식된 모든 텍스트 블록
  final List<OcrBlock> matchedBlocks; // 사용자 요청과 매칭된 블록
  final String userQuery;             // 사용자가 원하는 메뉴/항목
  final int imageWidth;
  final int imageHeight;

  const ScanResult({
    required this.allBlocks,
    required this.matchedBlocks,
    required this.userQuery,
    required this.imageWidth,
    required this.imageHeight,
  });

  bool get hasMatch => matchedBlocks.isNotEmpty;

  /// 가장 유력한 매칭 블록 (첫 번째)
  OcrBlock? get bestMatch => matchedBlocks.isNotEmpty ? matchedBlocks.first : null;
}
