# 키오스크 도우미 (Kiosk Helper) 🏪

어르신을 위한 **실시간 키오스크 사용 가이드 앱**

카메라로 키오스크를 비추면, 원하는 메뉴의 위치를 찾아 음성과 시각적 안내로 알려드립니다.

---

## 핵심 기능 (MVP)

- 📸 **카메라 스캔**: 키오스크 화면을 촬영
- 🔍 **OCR 텍스트 인식**: Google ML Kit (on-device, 무료, 한국어 지원)
- 🎯 **위치 가이드**: 매칭된 메뉴에 빨간 원 + 화살표 오버레이
- 🔊 **음성 안내**: "여기를 누르세요" TTS 음성 가이드
- 🎙️ **음성 입력**: 메뉴 이름을 말로 입력 가능

## 기술 스택

| 구성요소 | 기술 | 비용 |
|---------|------|------|
| 프레임워크 | Flutter 3.x (Dart) | 무료 |
| OCR | Google ML Kit Text Recognition | 무료 (on-device) |
| 음성 출력 | flutter_tts (시스템 TTS) | 무료 |
| 음성 입력 | speech_to_text (시스템 STT) | 무료 |
| 카메라 | camera 플러그인 | 무료 |

---

## 개발 환경 세팅 (처음부터)

### 1단계: Flutter 설치

```bash
# macOS (Homebrew)
brew install flutter

# Windows
# https://docs.flutter.dev/get-started/install/windows 에서 다운로드

# 설치 확인
flutter doctor
```

`flutter doctor`가 표시하는 체크리스트를 하나씩 해결하세요:
- Android Studio 설치 (Android SDK 포함)
- Xcode 설치 (iOS 빌드 시, macOS만)
- VS Code + Flutter 확장 설치 (추천 에디터)

### 2단계: 프로젝트 생성 + 코드 복사

```bash
# Flutter 프로젝트 생성
flutter create kiosk_helper
cd kiosk_helper

# 생성된 lib/ 폴더를 이 프로젝트의 lib/ 폴더로 교체
# pubspec.yaml도 이 프로젝트 파일로 교체

# 의존성 설치
flutter pub get
```

### 3단계: Android 설정

`android/app/build.gradle.kts` (또는 `.gradle`) 에서 minSdk를 수정:

```kotlin
android {
    defaultConfig {
        minSdk = 23  // ML Kit 최소 요구사항 (Android 6.0+)
        targetSdk = 34
    }
}
```

`android/app/src/main/AndroidManifest.xml`에 권한 추가:

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <!-- 카메라 -->
    <uses-permission android:name="android.permission.CAMERA"/>
    <!-- 음성 입력 -->
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <!-- 인터넷 (향후 Cloud AI 연동 시) -->
    <uses-permission android:name="android.permission.INTERNET"/>

    <application
        android:label="키오스크 도우미"
        ...>
        ...
    </application>
</manifest>
```

### 4단계: 실행

```bash
# Android 에뮬레이터 또는 실기기 연결 후
flutter run

# 릴리즈 빌드
flutter build apk --release
```

> ⚠️ **중요**: 카메라 기능은 에뮬레이터에서 제한적입니다.
> 실제 스마트폰에 USB 연결 후 테스트하는 것을 강력 추천합니다.

---

## 프로젝트 구조

```
lib/
├── main.dart                      # 앱 진입점 + 테마 설정
├── models/
│   └── scan_result.dart           # OCR 결과 데이터 모델
├── screens/
│   ├── home_screen.dart           # 메인 화면 (메뉴 입력)
│   └── scan_screen.dart           # 스캔 화면 (카메라 + OCR + 가이드)
├── services/
│   ├── ocr_service.dart           # Google ML Kit OCR 래퍼
│   └── voice_guide_service.dart   # TTS 음성 안내
└── widgets/
    └── guide_overlay.dart         # 빨간 원 + 화살표 오버레이 페인터
```

## 동작 흐름

```
[사용자] "아메리카노" 입력 (음성 or 텍스트)
    ↓
[카메라] 키오스크 화면 촬영
    ↓
[ML Kit OCR] 화면의 모든 텍스트 + 좌표 추출
    ↓
[매칭 엔진] "아메리카노" 포함 텍스트 블록 검색
    ├── 1단계: 정확 매칭 / 포함 매칭
    ├── 2단계: 키워드 분리 매칭
    └── 3단계: 문자 유사도 매칭
    ↓
[오버레이] 매칭 좌표에 빨간 원 + 화살표 + 펄스 애니메이션
    ↓
[TTS] "화면에서 아메리카노를 찾았습니다. 빨간 원이 표시된 곳을 눌러주세요."
    ↓
[사용자] 키오스크 터치 → "다음 단계" 버튼 → 다시 스캔
```

---

## 향후 로드맵

### v1.1 — On-Device VLM (무료 티어 강화)
- Florence-2 또는 PaliGemma 2를 ONNX로 변환하여 on-device 실행
- 이미지 기반 메뉴(텍스트 없는 아이콘 버튼)도 인식

### v1.2 — Cloud AI (프리미엄 구독)
- Claude Vision API / GPT-4o 연동
- "현재 화면이 무엇이고, 다음에 무엇을 해야 하는지" 추론
- 처음 보는 키오스크도 단계별 안내

### v1.3 — 커뮤니티 + 브랜드 DB
- 주요 프랜차이즈 키오스크 UI 패턴 DB 구축
- 사용자 기여형 키오스크 데이터 수집

---

## 라이선스

MIT License
